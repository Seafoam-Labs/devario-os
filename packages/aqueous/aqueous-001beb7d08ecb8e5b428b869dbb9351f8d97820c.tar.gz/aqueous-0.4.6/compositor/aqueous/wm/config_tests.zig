// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

test {
    _ = @import("config/actions.zig");
    _ = @import("config/layout.zig");
    _ = @import("config/loader.zig");
    _ = @import("config/wm.zig");
    _ = @import("output/config.zig");
    _ = @import("output/autolayout.zig");
    _ = @import("output/mode_match.zig");
    _ = @import("layout/engine.zig");
    _ = @import("rules/config.zig");
    _ = @import("state/store.zig");
    _ = @import("state/transient.zig");
}
