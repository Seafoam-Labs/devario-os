// SPDX-FileCopyrightText: © 2024 The River Developers
// SPDX-License-Identifier: GPL-3.0-only

const WindowManager = @This();

const std = @import("std");
const assert = std.debug.assert;
const wl = @import("wayland").server.wl;
const wlr = @import("wlroots");
const river = @import("wayland").server.river;
const SlotMap = @import("slotmap").SlotMap;

const server = &@import("main.zig").server;
const util = @import("util.zig");

const Output = @import("Output.zig");
const Scene = @import("Scene.zig");
const fx = @import("fx.zig");
const Seat = @import("Seat.zig");
const ShellSurface = @import("ShellSurface.zig");
const Window = @import("Window.zig");
const WmNode = @import("WmNode.zig");

const log = std.log.scoped(.wm);

global: *wl.Global,
server_destroy: wl.Listener(*wl.Server) = .init(handleServerDestroy),

/// The protocol object of the active window manager, if any.
object: ?*river.WindowManagerV1 = null,

state: union(enum) {
    idle,
    /// Waiting on the window manager client to send manage_finish.
    manage,
    /// The number of configures sent that have not yet been acked
    inflight_configures: u32,
    /// Waiting on the window manager client to send render_finish.
    render,
} = .idle,

windows: SlotMap(*Window) = .empty,

/// State to be sent to the wm in the next manage sequence.
scheduled: struct {
    /// State has been modified since the last manage sequence.
    /// Prevents processing further input events until a manage sequence is completed.
    dirty: bool = false,
    /// A manage sequence should be started when idle, but don't prevent processing
    /// further input events.
    dirty_lazy: bool = false,

    output_config: ?*wlr.OutputConfigurationV1 = null,
} = .{},

/// State sent to the wm in the latest update sequence.
sent: struct {
    session_locked: bool = false,

    outputs: wl.list.Head(Output, .link_sent),
    output_config: ?*wlr.OutputConfigurationV1 = null,

    seats: wl.list.Head(Seat, .link_sent),
},

/// Rendering state to be sent to the wm in the next render sequence.
rendering_scheduled: struct {
    /// Rendering state has been modified since the last render sequence.
    dirty: bool = false,
} = .{},

/// The list is in rendering order, the last node in the list is rendered on top.
rendering_requested: struct {
    list: wl.list.Head(WmNode, .link),
    order_hash: u64 = 0,
},

/// Global backdrop-blur state driven by river_window_manager_v1.set_blur. Blur
/// nodes and their geometry are owned by each output.
blur: struct {
    enabled: bool = false,
    radius: i32 = 0,
    passes: i32 = 0,
    appearance: fx.BlurAppearance = .{},
} = .{},

/// Default window-content opacity driven by river_window_manager_v1.set_opacity,
/// stored as the raw 32-bit unsigned fraction (0 = transparent, 0xffffffff = opaque).
/// Windows that received river_window_v1.set_window_opacity use their own value
/// instead of this default.
default_opacity: u32 = std.math.maxInt(u32),

/// Workspace-swap slide-transition state driven by
/// river_window_manager_v1.set_workspace_transition. `enabled` toggles whether
/// `Output.activateWorkspace` begins a slide (vs. an instant swap); `rate` paces
/// the slide's exponential smoothing. A non-positive `rate` means "use the
/// compile-time default" (`fx.workspace_slide_rate`).
workspace_transition: struct {
    enabled: bool = true,
    rate: f64 = fx.workspace_slide_rate,
} = .{},

dirty_idle: ?*wl.EventSource = null,

timeout: *wl.EventSource,

pub fn init(wm: *WindowManager) !void {
    const event_loop = server.wl_server.getEventLoop();
    const timeout = try event_loop.addTimer(*WindowManager, handleTimeout, wm);
    errdefer timeout.remove();

    wm.* = .{
        .global = try wl.Global.create(server.wl_server, river.WindowManagerV1, 10, *WindowManager, wm, bind),
        .sent = .{
            .outputs = undefined,
            .seats = undefined,
        },
        .rendering_requested = .{
            .list = undefined,
        },
        .timeout = timeout,
    };
    wm.sent.outputs.init();
    wm.sent.seats.init();
    wm.rendering_requested.list.init();

    server.wl_server.addDestroyListener(&wm.server_destroy);
}

fn handleServerDestroy(listener: *wl.Listener(*wl.Server), _: *wl.Server) void {
    const wm: *WindowManager = @fieldParentPtr("server_destroy", listener);

    wm.global.destroy();
    wm.timeout.remove();
}

fn bind(client: *wl.Client, wm: *WindowManager, version: u32, id: u32) void {
    const object = river.WindowManagerV1.create(client, version, id) catch {
        client.postNoMemory();
        log.err("out of memory", .{});
        return;
    };

    if (!server.aqueous.allowsExternal() or wm.object != null) {
        object.sendUnavailable();
        object.setHandler(?*anyopaque, handleRequestInert, null, null);
        return;
    }

    wm.object = object;
    object.setHandler(*WindowManager, handleRequest, handleDestroy, wm);
    wm.dirtyWindowing();
}

fn handleRequestInert(
    object: *river.WindowManagerV1,
    request: river.WindowManagerV1.Request,
    _: ?*anyopaque,
) void {
    if (request == .destroy) object.destroy();
}

fn handleDestroy(_: *river.WindowManagerV1, wm: *WindowManager) void {
    log.debug("active river_window_manager_v1 destroyed", .{});
    wm.object = null;
    {
        var it = server.om.outputs.iterator(.forward);
        while (it.next()) |output| output.makeInert();
    }
    {
        var it = server.input_manager.seats.iterator(.forward);
        while (it.next()) |seat| seat.makeInert();
    }
    {
        var it = wm.windows.iterator();
        while (it.next()) |window| window.makeInert();
    }
    switch (wm.state) {
        .idle => {},
        .inflight_configures => {},
        .manage => wm.manageFinish(),
        .render => wm.renderFinish(),
    }
}

fn handleRequest(
    wm_v1: *river.WindowManagerV1,
    request: river.WindowManagerV1.Request,
    wm: *WindowManager,
) void {
    assert(wm.object == wm_v1);
    switch (request) {
        .stop => {
            wm.object = null;
            wm_v1.sendFinished();
            wm_v1.setHandler(?*anyopaque, handleRequestInert, null, null);
        },
        // TODO send protocol error to avoid leak on race
        .destroy => wm_v1.destroy(),
        .manage_finish => {
            if (wm.state != .manage) {
                wm_v1.postError(.sequence_order,
                    \\manage_finish request does not match manage_start
                );
                return;
            }
            wm.manageFinish();
        },
        .manage_dirty => {
            wm.scheduled.dirty_lazy = true;
            wm.addDirtyIdle();
        },
        .render_finish => {
            if (wm.state != .render) {
                wm_v1.postError(.sequence_order,
                    \\render_finish request does not match render_start
                );
                return;
            }
            wm.renderFinish();
        },
        .get_shell_surface => |args| {
            const surface = wlr.Surface.fromWlSurface(args.surface);
            ShellSurface.create(
                wm_v1.getClient(),
                wm_v1.getVersion(),
                args.id,
                surface,
            ) catch {
                wm_v1.getClient().postNoMemory();
                log.err("out of memory", .{});
                return;
            };
        },
        .exit_session => {
            log.info("window manager requested to exit session", .{});
            server.wl_server.terminate();
        },
        .set_blur => |args| {
            if (!wm.ensureRendering()) return;
            // The client clamps these, but guard defensively against negatives
            // (the protocol documents them as out of range).
            wm.blur.enabled = args.enabled != 0;
            wm.blur.radius = if (args.radius > 0) args.radius else 0;
            wm.blur.passes = if (args.passes > 0) args.passes else 0;
            wm.applyBlur();
        },
        .set_blur_appearance => |args| {
            if (!wm.ensureRendering()) return;
            wm.blur.appearance = .{
                .noise = clampAppearance(args.noise.toDouble(), 0, 1),
                .contrast = clampAppearance(args.contrast.toDouble(), 0, 2),
                .brightness = clampAppearance(args.brightness.toDouble(), 0, 2),
                .vibrancy = clampAppearance(args.vibrancy.toDouble(), 0, 1),
                .vibrancy_darkness = clampAppearance(args.vibrancy_darkness.toDouble(), 0, 1),
            };
            wm.applyBlur();
        },
        .set_opacity => |args| {
            if (!wm.ensureRendering()) return;
            wm.default_opacity = args.value;
            var it = wm.windows.iterator();
            while (it.next()) |window| window.applyOpacity();
        },
        .set_workspace_transition => |args| {
            if (!wm.ensureRendering()) return;
            wm.workspace_transition.enabled = args.enabled != 0;
            // A non-positive rate means "keep the compile-time default pace".
            const rate = args.rate.toDouble();
            wm.workspace_transition.rate = if (rate > 0) rate else fx.workspace_slide_rate;
        },
    }
}

/// Apply the current global blur parameters and synchronize each output-local
/// optimized blur cache. No-op on builds without an effects backend.
fn applyBlur(wm: *WindowManager) void {
    if (comptime !fx.blur_available) return;
    const scene = server.scene.wlr_scene;
    const update = if (wm.blur.enabled)
        fx.setBlurParams(
            scene,
            @intCast(wm.blur.radius),
            @intCast(wm.blur.passes),
            wm.blur.appearance,
        )
    else
        fx.setBlurParams(scene, 0, 0, wm.blur.appearance);

    var layer_surfaces = server.layer_shell.surfaces.iterator();
    while (layer_surfaces.next()) |surface| surface.syncBlurEffects();

    var outputs = server.om.outputs.iterator(.forward);
    while (outputs.next()) |output| {
        output.syncBlur(update.kernel_changed);
        if (wm.blur.enabled and update.appearance_changed) {
            output.damageBlurAppearance();
        }
    }
}

fn clampAppearance(value: f64, minimum: f64, maximum: f64) f32 {
    if (!std.math.isFinite(value)) return @floatCast(minimum);
    return @floatCast(std.math.clamp(value, minimum, maximum));
}

pub fn policyApplyGlobals(
    wm: *WindowManager,
    blur_enabled: bool,
    blur_radius: i32,
    blur_passes: i32,
    blur_appearance: fx.BlurAppearance,
    opacity: f64,
    transition_enabled: bool,
    transition_rate: f64,
) void {
    wm.blur.enabled = blur_enabled;
    wm.blur.radius = @max(0, blur_radius);
    wm.blur.passes = @max(0, blur_passes);
    wm.blur.appearance = blur_appearance;
    wm.applyBlur();
    const clamped_opacity = std.math.clamp(opacity, 0, 1);
    wm.default_opacity = @intFromFloat(clamped_opacity * @as(f64, @floatFromInt(std.math.maxInt(u32))));
    var windows = wm.windows.iterator();
    while (windows.next()) |window| window.applyOpacity();
    wm.workspace_transition.enabled = transition_enabled;
    wm.workspace_transition.rate = if (transition_rate > 0) transition_rate else fx.workspace_slide_rate;
}

pub fn ensureWindowing(wm: *WindowManager) bool {
    switch (wm.state) {
        .manage => return true,
        .idle, .inflight_configures, .render => {
            if (wm.object) |wm_v1| {
                wm_v1.postError(.sequence_order, "invalid modification of window management state");
            }
            return false;
        },
    }
}

pub fn ensureRendering(wm: *WindowManager) bool {
    switch (wm.state) {
        .manage, .inflight_configures, .render => return true,
        .idle => {
            if (wm.object) |wm_v1| {
                wm_v1.postError(.sequence_order, "invalid modification of rendering state");
            }
            return false;
        },
    }
}

pub fn dirtyWindowing(wm: *WindowManager) void {
    wm.scheduled.dirty = true;
    wm.addDirtyIdle();
}

pub fn dirtyWindowingLazy(wm: *WindowManager) void {
    wm.scheduled.dirty_lazy = true;
    wm.addDirtyIdle();
}

pub fn cleanWindowing(wm: *WindowManager) void {
    wm.scheduled.dirty = false;
    wm.removeDirtyIdle();
}

pub fn dirtyRendering(wm: *WindowManager) void {
    wm.rendering_scheduled.dirty = true;
    wm.addDirtyIdle();
}

pub fn cleanRendering(wm: *WindowManager) void {
    wm.rendering_scheduled.dirty = false;
    wm.removeDirtyIdle();
}

fn addDirtyIdle(wm: *WindowManager) void {
    assert(wm.scheduled.dirty or wm.scheduled.dirty_lazy or wm.rendering_scheduled.dirty);
    if (wm.dirty_idle == null) {
        const event_loop = server.wl_server.getEventLoop();
        wm.dirty_idle = event_loop.addIdle(*WindowManager, dirtyIdle, wm) catch {
            log.err("out of memory", .{});
            return;
        };
    }
}

fn removeDirtyIdle(wm: *WindowManager) void {
    if (!wm.scheduled.dirty and !wm.rendering_scheduled.dirty) {
        if (wm.dirty_idle) |event_source| {
            event_source.remove();
            wm.dirty_idle = null;
        }
    }
}

fn dirtyIdle(wm: *WindowManager) void {
    assert(wm.scheduled.dirty or wm.scheduled.dirty_lazy or wm.rendering_scheduled.dirty);
    wm.dirty_idle = null;
    switch (wm.state) {
        .idle => {
            if (wm.rendering_scheduled.dirty) {
                wm.renderStart();
            } else {
                assert(wm.scheduled.dirty or wm.scheduled.dirty_lazy);
                wm.scheduled.dirty = true;
                wm.scheduled.dirty_lazy = false;
                wm.manageStart();
            }
        },
        .manage, .inflight_configures, .render => {},
    }
}

fn manageStart(wm: *WindowManager) void {
    assert(wm.state == .idle);
    assert(wm.scheduled.dirty);
    wm.cleanWindowing();
    wm.state = .manage;

    log.debug("manage sequence start", .{});

    const session_locked = server.lock_manager.state == .locked;
    if (session_locked != wm.sent.session_locked) {
        if (wm.object) |wm_v1| {
            if (session_locked) {
                wm_v1.sendSessionLocked();
            } else {
                wm_v1.sendSessionUnlocked();
            }
        }
        wm.sent.session_locked = session_locked;
    }

    server.om.autoLayout();
    {
        var it = server.om.outputs.safeIterator(.forward);
        while (it.next()) |output| output.manageStart();
    }

    assert(wm.sent.output_config == null);
    wm.sent.output_config = wm.scheduled.output_config;
    wm.scheduled.output_config = null;

    {
        var it = wm.windows.iterator();
        while (it.next()) |window| window.manageStart();
    }

    {
        var it = server.input_manager.seats.safeIterator(.forward);
        while (it.next()) |seat| seat.manageStart();
    }

    server.aqueous.traceCycle(.manage_start, wm.object != null);

    if (wm.object) |wm_v1| {
        wm_v1.sendManageStart();
        wm.startTimeoutTimer(3000);
    } else {
        server.aqueous.applyManageCycle() catch |err| {
            log.err("internal policy manage cycle failed: {}", .{err});
        };
        wm.manageFinish();
    }
}

pub fn manageFinish(wm: *WindowManager) void {
    assert(wm.state == .manage);
    wm.cancelTimeoutTimer();

    log.debug("manage sequence finish", .{});
    server.aqueous.traceCycle(.manage_finish, wm.object != null);

    // Order is important here, Seat.manageFinish() must be called before
    // Window.manageFinish(). External policy finalizes only seats advertised to
    // its protocol object. Integrated policy has no such objects/list, so it
    // must finalize the compositor's seats directly or scheduled focus never
    // reaches wl_seat (and clients receive no keyboard enter event).
    if (wm.object != null) {
        var it = wm.sent.seats.iterator(.forward);
        while (it.next()) |seat| seat.manageFinish();
    } else {
        var it = server.input_manager.seats.safeIterator(.forward);
        while (it.next()) |seat| seat.manageFinish();
    }

    wm.state = .{ .inflight_configures = 0 };
    {
        var it = wm.rendering_requested.list.iterator(.forward);
        while (it.next()) |node| {
            switch (node.get()) {
                .window => |window| {
                    if (window.manageFinish()) {
                        wm.state.inflight_configures += 1;
                    }
                },
                .shell_surface => {},
            }
        }
    }

    log.debug("sent {} tracked configure(s)", .{wm.state.inflight_configures});

    if (wm.state.inflight_configures > 0) {
        wm.startTimeoutTimer(100);
    } else {
        wm.renderStart();
    }
}

fn startTimeoutTimer(wm: *WindowManager, ms: u31) void {
    wm.timeout.timerUpdate(ms) catch {
        log.err("failed to start timer", .{});
        _ = wm.handleTimeout();
    };
}

fn cancelTimeoutTimer(wm: *WindowManager) void {
    wm.timeout.timerUpdate(0) catch log.err("error disarming timer", .{});
}

fn handleTimeout(wm: *WindowManager) c_int {
    switch (wm.state) {
        .inflight_configures => {
            log.err("timeout occurred, some imperfect frames may be shown", .{});
            assert(wm.state.inflight_configures > 0);
            wm.state.inflight_configures = 0;

            wm.renderStart();
        },
        .manage, .render => if (wm.object) |wm_v1| {
            log.err("window manager unresponsive for more than 3 seconds, disconnecting", .{});
            wm_v1.postError(.unresponsive, "unresponsive for more than 3 seconds");
            // Don't wait for the frozen client to receive the protocol error
            // and exit of its own accord.
            wm_v1.getClient().destroy();
        },
        .idle => unreachable,
    }

    return 0;
}

pub fn notifyConfigured(wm: *WindowManager) void {
    wm.state.inflight_configures -= 1;
    if (wm.state.inflight_configures == 0) {
        wm.cancelTimeoutTimer();
        wm.renderStart();
    }
}

fn renderStart(wm: *WindowManager) void {
    assert((wm.state == .idle and wm.rendering_scheduled.dirty) or
        wm.state.inflight_configures == 0);
    wm.state = .render;
    wm.cleanRendering();

    log.debug("render sequence start", .{});
    server.aqueous.traceCycle(.render_start, wm.object != null);

    {
        var it = wm.rendering_requested.list.iterator(.forward);
        while (it.next()) |node| {
            switch (node.get()) {
                .window => |window| window.renderStart(),
                .shell_surface => {},
            }
        }
    }

    if (wm.object) |wm_v1| {
        wm_v1.sendRenderStart();
        wm.startTimeoutTimer(3000);
    } else {
        wm.renderFinish();
    }
}

/// Finish the update sequence and drop stashed buffers. This means that
/// the next frame drawn will be the post-transaction state.
fn renderFinish(wm: *WindowManager) void {
    assert(wm.state == .render);
    wm.state = .idle;

    wm.cancelTimeoutTimer();

    log.debug("render sequence finish", .{});
    server.aqueous.traceCycle(.render_finish, wm.object != null);

    {
        var it = wm.windows.iterator();
        while (it.next()) |window| {
            // If a window is unmapped during a render sequence, we need to retain the saved
            // buffers until after the next manage sequence (in which the closed event will
            // be sent) for frame perfection.
            if (window.state != .closing) {
                window.surfaces.dropSaved();
            }
            // Ensure windows that are closed but not yet destroyed don't have
            // their borders/decorations rendered.
            if (window.state == .init) {
                window.tree.node.reparent(server.scene.hidden_tree);
            }
            if (window.impl == .destroying) {
                window.destroy();
            }
        }
    }

    // This is a hack to avoid excessive modification of the wlroots scene graph.
    // There is currently no way to atomically apply multiple changes to the
    // scene graph, which means that damage and visibility are re-calculated
    // every API call, resulting in redundant events being sent to clients.
    //
    // TODO(wlroots) provide a way to batch changes to the scene graph.
    const new_order_hash = blk: {
        var hash = std.crypto.hash.Blake3.init(.{});
        var it = wm.rendering_requested.list.iterator(.forward);
        while (it.next()) |node| {
            switch (node.get()) {
                .window => |window| {
                    hash.update(@ptrCast(&window.ref));
                    hash.update(&.{@intFromBool(window.wm_requested.fullscreen != null)});
                },
                .shell_surface => |shell_surface| {
                    hash.update(@ptrCast(&shell_surface));
                },
            }
        }
        var final: u64 = undefined;
        hash.final(@ptrCast(&final));
        break :blk final;
    };

    {
        const reorder = wm.rendering_requested.order_hash != new_order_hash;
        wm.rendering_requested.order_hash = new_order_hash;

        var found_fullscreen: bool = false;
        var it = wm.rendering_requested.list.iterator(.forward);
        while (it.next()) |node| {
            switch (node.get()) {
                .window => |window| {
                    window.renderFinish();
                    if (!reorder) continue;
                    if (window.wm_requested.fullscreen != null) {
                        window.tree.node.reparent(server.scene.layers.fullscreen);
                        window.tree.node.raiseToTop();
                        found_fullscreen = true;
                    } else {
                        window.tree.node.reparent(server.scene.layers.wm);
                        window.tree.node.raiseToTop();
                    }
                },
                .shell_surface => |shell_surface| {
                    shell_surface.renderFinish();
                    if (!reorder) continue;
                    shell_surface.popup_tree.node.reparent(server.scene.layers.popups);
                    if (found_fullscreen) {
                        shell_surface.tree.node.reparent(server.scene.layers.fullscreen);
                    } else {
                        shell_surface.tree.node.reparent(server.scene.layers.wm);
                    }
                    shell_surface.tree.node.raiseToTop();
                },
            }
        }

        // The reorder loop above re-raised every window's live `tree` but never the
        // animation clones, so any in-flight slide clone has just been buried by the
        // opaque live trees. Lift each active clone back above its siblings, in list
        // order so later clones sit above earlier ones (matching the live stacking the
        // loop established). Gated on `reorder` so it costs nothing on the common path.
        if (reorder) {
            var it2 = wm.rendering_requested.list.iterator(.forward);
            while (it2.next()) |node| {
                switch (node.get()) {
                    .window => |window| window.raiseSnapshotIfActive(),
                    .shell_surface => {},
                }
            }

            // A blur checkpoint depends on every scene node below its marker,
            // not just on the marker's geometry. Focus changes can reorder
            // otherwise stationary windows, so invalidate cached checkpoints
            // before this transaction is rendered.
            var outputs = server.om.outputs.iterator(.forward);
            while (outputs.next()) |output| output.invalidateBlurSources();
        }
    }

    // Now that every window's renderFinish has run, any pending workspace-swap
    // slide has been seeded/armed. Mark each transitioning output so that
    // finalizeTransition is allowed to complete it; doing it here (rather than
    // in Window.renderFinish) also correctly handles switches with no windows
    // to animate, which would otherwise leave prev_workspace stuck forever.
    {
        var it = server.om.outputs.iterator(.forward);
        while (it.next()) |output| {
            if (output.prev_workspace != null) output.transition_armed = true;
        }
    }

    server.om.commitOutputState();

    {
        var it = server.input_manager.seats.iterator(.forward);
        while (it.next()) |seat| seat.cursor.updateState();
    }

    server.idle_inhibit_manager.checkActive();

    log.debug("finished committing transaction", .{});

    if (wm.scheduled.dirty or wm.scheduled.dirty_lazy or wm.rendering_scheduled.dirty) {
        wm.addDirtyIdle();
    }

    server.input_manager.processEvents();
}
