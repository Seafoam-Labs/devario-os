// SPDX-FileCopyrightText: © 2026 Seafoam Labs
// SPDX-License-Identifier: GPL-3.0-only

const build_options = @import("build_options");
const std = @import("std");
const mem = std.mem;
const fs = std.fs;
const Io = std.Io;
const log = std.log;
const posix = std.posix;
const exit = std.process.exit;
const fatal = std.process.fatal;

const builtin = @import("builtin");
const wlr = @import("wlroots");
const flags = @import("flags");

const util = @import("util.zig");
const process = @import("process.zig");

const Server = @import("Server.zig");
const PolicyMode = @import("wm/Mode.zig").Mode;

const io = Io.Threaded.global_single_threaded.io();

const usage: []const u8 =
    \\usage: aqueous [options]
    \\
    \\  -h                 Print this help message and exit.
    \\  -version           Print the version number and exit.
    \\  -c <command>       Run `sh -c <command>` on startup instead of the default init executable.
    \\  -log-level <level> Set the log level to error, warning, info, or debug.
    \\  -policy <mode>      Select internal policy (or external/compare when built with compatibility support).
    \\  -no-xwayland       Disable xwayland even if built with support.
    \\
;

const full_version = std.fmt.comptimePrint("aqueous {s} {c}xwayland", .{
    build_options.version,
    if (build_options.xwayland) '+' else '-',
});

pub var server: Server = undefined;
extern fn setenv(name: [*:0]const u8, value: [*:0]const u8, overwrite: c_int) c_int;

fn inheritAssignment(name: [*:0]const u8, assignment: [:0]const u8) void {
    const equal = mem.indexOfScalar(u8, assignment, '=') orelse return;
    _ = setenv(name, assignment.ptr + equal + 1, 1);
}

pub fn main(init: std.process.Init.Minimal) anyerror!void {
    var arena_alloc = std.heap.ArenaAllocator.init(util.gpa);
    defer arena_alloc.deinit();
    const arena = arena_alloc.allocator();

    var stdout_buffer: [64]u8 = undefined;
    var stdout_writer = Io.File.stdout().writer(io, &stdout_buffer);
    const stdout = &stdout_writer.interface;

    var stderr_buffer: [64]u8 = undefined;
    var stderr_writer = Io.File.stderr().writer(io, &stderr_buffer);
    const stderr = &stderr_writer.interface;

    const args = try init.args.toSlice(arena);

    const result = flags.parser(&.{
        .{ .name = "h", .kind = .boolean },
        .{ .name = "version", .kind = .boolean },
        .{ .name = "c", .kind = .arg },
        .{ .name = "log-level", .kind = .arg },
        .{ .name = "policy", .kind = .arg },
        .{ .name = "log-scopes", .kind = .arg },
        .{ .name = "no-xwayland", .kind = .boolean },
    }).parse(args[1..]) catch {
        try stderr.writeAll(usage);
        try stderr.flush();
        exit(1);
    };
    if (result.flags.h) {
        try stdout.writeAll(usage);
        try stdout.flush();
        exit(0);
    }
    if (result.args.len != 0) {
        log.err("unknown option '{s}'", .{result.args[0]});
        try stderr.writeAll(usage);
        try stderr.flush();
        exit(1);
    }

    if (result.flags.version) {
        try stdout.writeAll(full_version ++ "\n");
        try stdout.flush();
        exit(0);
    }
    if (result.flags.@"log-level") |level| {
        if (mem.eql(u8, level, "error")) {
            runtime_log_level = .err;
        } else if (mem.eql(u8, level, "warning")) {
            runtime_log_level = .warn;
        } else if (mem.eql(u8, level, "info")) {
            runtime_log_level = .info;
        } else if (mem.eql(u8, level, "debug")) {
            runtime_log_level = .debug;
        } else {
            fatal("invalid log level '{s}'", .{level});
        }
    }
    if (result.flags.@"log-scopes") |scopes| {
        // Examples:
        // -log-scopes input,wm     (only default, input, and wm scopes)
        // -log-scopes all,~wlroots (all scopes except wlroots)
        log_scopes = std.EnumSet(LogScope).initEmpty();
        var it = mem.splitScalar(u8, scopes, ',');
        while (it.next()) |raw| {
            if (mem.eql(u8, raw, "all")) {
                log_scopes = std.EnumSet(LogScope).initFull();
            } else if (raw.len > 0 and raw[0] == '~') {
                // I'd rather use an exclamation mark than a tilde but the
                // former requires quoting in most shells.
                const scope = std.meta.stringToEnum(LogScope, raw[1..]) orelse {
                    fatal("invalid log scope '{s}'", .{raw});
                };
                log_scopes.remove(scope);
            } else {
                const scope = std.meta.stringToEnum(LogScope, raw) orelse {
                    fatal("invalid log scope '{s}'", .{raw});
                };
                log_scopes.insert(scope);
            }
        }
    }
    const runtime_xwayland = !result.flags.@"no-xwayland";
    const policy_mode = if (result.flags.policy) |value|
        PolicyMode.parse(value) orelse fatal("invalid policy mode '{s}'", .{value})
    else
        PolicyMode.internal;
    if (!build_options.external_policy and policy_mode != .internal) {
        fatal("policy mode '{s}' requires a build with -Dexternal-policy=true", .{@tagName(policy_mode)});
    }
    const startup_command = blk: {
        if (result.flags.c) |command| {
            break :blk try util.gpa.dupeZ(u8, command);
        } else {
            break :blk try defaultInitPath(init.environ);
        }
    };
    defer if (startup_command) |cmd| util.gpa.free(cmd);

    try detectClassic(startup_command);

    log.info("initializing Aqueous version {s}", .{full_version});
    if (build_options.xwayland and !runtime_xwayland) {
        log.info("Xwayland disabled at runtime with -no-xwayland", .{});
    }

    river_init_wlroots_log(switch (runtime_log_level) {
        .debug => .debug,
        .info => .info,
        .warn, .err => .err,
    });

    try server.init(runtime_xwayland, policy_mode);
    defer server.deinit();

    // wlroots starts the Xwayland process from an idle event source, the reasoning being that
    // this gives the compositor time to set up event listeners before Xwayland is actually
    // started. We want Xwayland to be started by wlroots before we modify our rlimits in
    // process.setup() since wlroots does not offer a way for us to reset the rlimit post-fork.
    if (build_options.xwayland and runtime_xwayland) {
        server.wl_server.getEventLoop().dispatchIdle();
    }

    process.setup();

    var buf: [11]u8 = undefined;
    const socket = try server.wl_server.addSocketAuto(&buf);
    try server.backend.start();
    // Native [[exec]] and keybinding children inherit the compositor socket.
    // This is intentionally delayed until addSocketAuto() has produced it.
    if (setenv("WAYLAND_DISPLAY", socket.ptr, 1) != 0) return error.SetEnvironmentFailed;
    if (build_options.xwayland) {
        if (server.xwayland) |xwayland| _ = setenv("DISPLAY", xwayland.display_name, 1);
    }
    if (server.gpu_pin.vk_select) |value| inheritAssignment("MESA_VK_DEVICE_SELECT", value);
    if (server.gpu_pin.gl_vendor) |value| inheritAssignment("__GLX_VENDOR_LIBRARY_NAME", value);
    if (server.gpu_pin.dri_prime) |value| inheritAssignment("DRI_PRIME", value);
    if (server.gpu_pin.nv_offload) |value| inheritAssignment("__NV_PRIME_RENDER_OFFLOAD", value);
    server.aqueous.start();

    // Run the child in a new process group so that we can send SIGTERM to all
    // descendants on exit.
    const child_pgid = if (startup_command) |cmd| blk: {
        log.info("running init executable '{s}'", .{cmd});

        // Build child env directly from the inherited environ, reusing the
        // original NUL-terminated KEY=VALUE strings unchanged. This avoids
        // round-tripping through EnvMap, which can mis-handle values containing
        // whitespace or other characters on certain stdlib code paths and
        // crash Aqueous on startup. Spaces in values are perfectly valid
        // POSIX, so passing the kernel-supplied entries through verbatim is
        // both correct and robust.
        const wayland_display = try std.fmt.allocPrintSentinel(
            util.gpa,
            "WAYLAND_DISPLAY={s}",
            .{socket},
            0,
        );
        defer util.gpa.free(wayland_display);

        var display_buf: ?[:0]u8 = null;
        defer if (display_buf) |d| util.gpa.free(d);
        if (build_options.xwayland) {
            if (server.xwayland) |xwayland| {
                display_buf = try std.fmt.allocPrintSentinel(
                    util.gpa,
                    "DISPLAY={s}",
                    .{mem.sliceTo(xwayland.display_name, 0)},
                    0,
                );
            }
        }

        var env_list: std.ArrayList(?[*:0]const u8) = .empty;
        defer env_list.deinit(util.gpa);

        // Iterate the inherited envp via its NUL-terminated many-pointer so we
        // stop at the sentinel rather than walking past it. Using
        // `block.view().slice` would include the trailing null entry and cause
        // `mem.sliceTo` to dereference a null pointer.
        const envp_in: [*:null]const ?[*:0]const u8 = init.environ.block.slice.ptr;
        var i: usize = 0;
        while (envp_in[i]) |entry| : (i += 1) {
            const name = mem.sliceTo(entry, '=');
            if (mem.eql(u8, name, "WAYLAND_DISPLAY")) continue;
            if (mem.eql(u8, name, "DISPLAY")) continue;
            // Drop any inherited copy of a GPU-pin var we are about to set so a
            // stale value (e.g. from a nested session) cannot shadow the
            // compositor's choice. Mirrors the WAYLAND_DISPLAY filter above.
            if (server.gpu_pin.vk_select != null and mem.eql(u8, name, "MESA_VK_DEVICE_SELECT")) continue;
            if (server.gpu_pin.gl_vendor != null and mem.eql(u8, name, "__GLX_VENDOR_LIBRARY_NAME")) continue;
            if (server.gpu_pin.dri_prime != null and mem.eql(u8, name, "DRI_PRIME")) continue;
            if (server.gpu_pin.nv_offload != null and mem.eql(u8, name, "__NV_PRIME_RENDER_OFFLOAD")) continue;
            try env_list.append(util.gpa, entry);
        }
        try env_list.append(util.gpa, wayland_display.ptr);
        if (display_buf) |d| try env_list.append(util.gpa, d.ptr);
        // Append the resolved GPU-pin selector vars (each null unless applicable
        // or on single-GPU systems), exactly like WAYLAND_DISPLAY. Downstream
        // clients inherit these through the WM's environment.
        if (server.gpu_pin.vk_select) |s| try env_list.append(util.gpa, s.ptr);
        if (server.gpu_pin.gl_vendor) |s| try env_list.append(util.gpa, s.ptr);
        if (server.gpu_pin.dri_prime) |s| try env_list.append(util.gpa, s.ptr);
        if (server.gpu_pin.nv_offload) |s| try env_list.append(util.gpa, s.ptr);
        try env_list.append(util.gpa, null);

        const envp: [*:null]const ?[*:0]const u8 = @ptrCast(env_list.items.ptr);

        const child_args = [_:null]?[*:0]const u8{ "/bin/sh", "-c", cmd, null };

        const pid: posix.pid_t = fork: {
            const rc = posix.system.fork();
            switch (posix.errno(rc)) {
                .SUCCESS => break :fork @intCast(rc),
                .AGAIN => return error.SystemResources,
                .NOMEM => return error.SystemResources,
                .NOSYS => return error.OperationUnsupported,
                else => |err| return posix.unexpectedErrno(err),
            }
        };

        if (pid == 0) {
            process.cleanupChild();
            if (posix.errno(posix.system.execve("/bin/sh", &child_args, envp)) != .SUCCESS) {
                posix.system.exit(1);
            }
        }
        // Since the child has called setsid, the pid is the pgid
        break :blk pid;
    } else null;
    defer if (child_pgid) |pgid| posix.kill(-pgid, posix.SIG.TERM) catch |err| {
        log.err("failed to kill init process group: {s}", .{@errorName(err)});
    };

    log.info("running server", .{});

    server.wl_server.run();
}

fn defaultInitPath(environ: std.process.Environ) !?[:0]const u8 {
    const path = blk: {
        if (environ.getPosix("XDG_CONFIG_HOME")) |xdg_config_home| {
            break :blk try fs.path.joinZ(util.gpa, &[_][]const u8{ xdg_config_home, "aqueous/init" });
        } else if (environ.getPosix("HOME")) |home| {
            break :blk try fs.path.joinZ(util.gpa, &[_][]const u8{ home, ".config/aqueous/init" });
        } else {
            return null;
        }
    };

    Io.Dir.cwd().access(io, path, .{ .execute = true }) catch |err| {
        if (err == error.PermissionDenied) {
            if (Io.Dir.cwd().access(io, path, .{})) {
                fatal("failed to run init executable {s}: the file is not executable", .{path});
            } else |_| {}
        }
        log.err("failed to run init executable {s}: {s}", .{ path, @errorName(err) });
        util.gpa.free(path);
        return null;
    };

    return path;
}

fn detectClassic(startup_command: ?[:0]const u8) !void {
    const path = startup_command orelse return;
    if (mem.indexOfScalar(u8, path, '/') == null) return;

    const classic = grepRiverctl(path) catch |err| {
        log.debug("failed to detect riverctl usage in init file: {s}", .{@errorName(err)});
        return;
    };
    if (classic) {
        fatal(
            \\The init file {[path]s} contains the string "riverctl".
            \\This Aqueous version ({[version]s}) does not support riverctl, you may
            \\wish to install river-classic instead.
            \\
            \\Aqueous {[version]s} uses its integrated window-management policy;
            \\riverctl configuration is not supported.
            \\
        , .{
            .path = path,
            .version = build_options.version,
        });
    }
}

fn grepRiverctl(path: [:0]const u8) !bool {
    var file = try Io.Dir.cwd().openFile(io, path, .{});
    defer file.close(io);
    var buffer: [1024]u8 = undefined;
    var file_reader = file.reader(io, &buffer);
    const reader = &file_reader.interface;
    while (true) {
        _ = try reader.discardDelimiterExclusive('r');
        const bytes = reader.peekArray("riverctl".len) catch |err| switch (err) {
            error.EndOfStream => return false,
            else => |e| return e,
        };
        if (mem.eql(u8, bytes, "riverctl")) {
            return true;
        }
        reader.toss(1);
    }
}

// Scopes should be added to this list sparingly.
// Only add new scopes if filtering based on them would be meaningful.
const LogScope = enum {
    default,
    wlroots,
    output,
    input,
    lock,
    wm,
    overview,
    aqueous,
    output_service,
    workspace,
    xdg,
    xwayland,
};

var log_scopes: std.EnumSet(LogScope) = std.EnumSet(LogScope).initFull();

/// Set the default log level based on the build mode.
var runtime_log_level: log.Level = switch (builtin.mode) {
    .Debug => .debug,
    .ReleaseSafe, .ReleaseFast, .ReleaseSmall => .info,
};

pub const std_options: std.Options = .{
    // Tell std.log to leave all log level filtering to us.
    .log_level = .debug,
    .logFn = logFn,
};

pub fn logFn(
    comptime level: log.Level,
    comptime scope: @TypeOf(.EnumLiteral),
    comptime format: []const u8,
    args: anytype,
) void {
    if (@intFromEnum(level) > @intFromEnum(runtime_log_level)) return;

    if (scope != .default and !log_scopes.contains(scope)) return;

    log.defaultLog(level, scope, format, args);
}

/// See wlroots_log_wrapper.c
extern fn river_init_wlroots_log(importance: wlr.log.Importance) void;
export fn river_wlroots_log_callback(importance: wlr.log.Importance, ptr: [*:0]const u8, len: usize) void {
    const wlr_log = log.scoped(.wlroots);
    switch (importance) {
        .err => wlr_log.err("{s}", .{ptr[0..len]}),
        .info => wlr_log.info("{s}", .{ptr[0..len]}),
        .debug => wlr_log.debug("{s}", .{ptr[0..len]}),
        .silent, .last => unreachable,
    }
}
